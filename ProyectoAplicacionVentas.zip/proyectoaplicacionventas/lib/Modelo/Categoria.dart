class Categoria {
  String nombre = '';
}
