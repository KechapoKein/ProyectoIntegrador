import 'package:flutter/material.dart';
import 'package:proyectoaplicacionventas/Vista/Menu.dart';

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Punto de Venta',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: inicio(context),
    );
  }
}

Widget inicio(BuildContext context) {
  return Container(
    color: const Color.fromARGB(255, 236, 19, 19), // Fondo negro
    padding: const EdgeInsets.all(16.0), // Margen para evitar que todo quede pegado a los bordes
    child: Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          textoDecorativo(), // Texto superior
          const SizedBox(height: 50), // Espacio entre el texto decorativo y "Iniciar Sesión"
          nombre(),
          campoUsuario(),
          campoContrasena(),
          const SizedBox(height: 15),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              botonEntrar(context), // Aquí pasamos el contexto
              const SizedBox(width: 10),
              //botonCrear(),
            ],
          ),
        ],
      ),
    ),
  );
}

Widget textoDecorativo() {
  return const Text(
    "Punto de Venta 'En una pieza', Calidad y Precios que son un Tesoro",
    textAlign: TextAlign.center, // Centrar el texto
    style: TextStyle(
      color: Color.fromARGB(255, 245, 255, 100), // Color del texto
      fontSize: 24.0, // Tamaño de letra
      fontWeight: FontWeight.bold, // Negrita
    ),
  );
}

Widget nombre() {
  return const Text(
    "Iniciar Sesión",
    style: TextStyle(
      color: Color.fromARGB(255, 33, 243, 149), 
      fontSize: 35.0, 
      fontWeight: FontWeight.bold,
    ),
  );
}

Widget campoUsuario() {
  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 3),
    child: const TextField(
      decoration: InputDecoration(
        hintText: "Usuario",
        fillColor: Color.fromARGB(130, 255, 255, 255),
        filled: true,
      ),
    ),
  );
}

Widget campoContrasena() {
  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
    child: const TextField(
      obscureText: true,
      decoration: InputDecoration(
        hintText: "Contraseña",
        fillColor: Color.fromARGB(130, 255, 255, 255),
        filled: true,
      ),
    ),
  );
}

Widget botonEntrar(BuildContext context) {
  return Container(
    child: ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: const Color.fromARGB(251, 233, 255, 242),
        foregroundColor: const Color.fromARGB(255, 148, 241, 206),
        padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
      ),
      onPressed: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => MenuVista()),
        );
      },
      child: const Text("Iniciar Sesión"),
    ),
  );
}
