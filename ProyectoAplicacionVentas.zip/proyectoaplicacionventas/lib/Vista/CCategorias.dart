import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';


class CrearCategoriaVista extends StatelessWidget {
  final TextEditingController nombreCategoriaController = TextEditingController();
  CrearCategoriaVista({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('| --- Agregar Categoría --- |',
            style: TextStyle(color: Color(0xFF000080))), // Color azul rey
        backgroundColor: Colors.white, // Fondo blanco del AppBar
      ),
      backgroundColor: const Color(0xFFFFFF00), // Fondo amarillo
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0), // Padding para evitar bordes pegados
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center, // Centrar el contenido
            children: <Widget>[
              TextField(
                controller: nombreCategoriaController,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Nombre de la categoría',
                ),
              ),
              const SizedBox(height: 20), // Separador entre el campo y el botón
              ElevatedButton(
                onPressed: () {
                  var box = Hive.box('categorias');
                  box.add(nombreCategoriaController.text);
                  if (kDebugMode) {
                    print(box.toMap());
                  }
                  Navigator.pop(context);
                },
                child: const Text('Guardar'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}