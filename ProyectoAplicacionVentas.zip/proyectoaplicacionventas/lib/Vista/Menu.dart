import 'package:proyectoaplicacionventas/Modelo/Producto.dart';
import 'package:proyectoaplicacionventas/Vista/Categorias.dart';
import 'package:proyectoaplicacionventas/Vista/Productos.dart';
import 'package:proyectoaplicacionventas/Vista/Cproductos.dart';
import 'package:proyectoaplicacionventas/Vista/CCategorias.dart';
import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';

class MenuVista extends StatelessWidget {
  MenuVista({Key? key}) : super(key: key);

  final List<Producto> productos = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('| --- Menú --- |'),
        backgroundColor: const Color.fromRGBO(112, 255, 253, 1),
      ),
      backgroundColor: const Color.fromARGB(255, 33, 243, 149), // Fondo cambiado
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center, // Centrar verticalmente
          children: <Widget>[
            const Spacer(), // Espacio flexible en la parte superior
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => AgregarProductoVista(
                      productos: productos,
                    ),
                  ),
                );
              },
              child: const Text('Agregar Productos'),
            ),
            const SizedBox(height: 20), // Separador entre botones
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => VerProductosVista(),
                  ),
                );
              },
              child: const Text('Ver Productos'),
            ),
            const SizedBox(height: 20), // Separador entre botones
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) {
                      return CrearCategoriaVista();
                    },
                  ),
                );
              },
              child: const Text('Agregar Categorías'),
            ),
            const SizedBox(height: 20), // Separador entre botones
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) {
                      return const CategoriasVista();
                    },
                  ),
                );
              },
              child: const Text('Ver Categorías'),
            ),
            const SizedBox(height: 20), // Separador
            const Text(
              "Próximamente, Tienda lista con permiso para vender",
              style: TextStyle(fontSize: 14, color: Colors.black), // Tamaño de texto más pequeño
            ),
            const Spacer(), // Espacio flexible en la parte inferior
          ],
        ),
      ),
    );
  }
}