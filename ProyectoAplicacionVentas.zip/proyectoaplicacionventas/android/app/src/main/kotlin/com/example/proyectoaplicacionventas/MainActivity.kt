package com.example.proyectoaplicacionventas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
